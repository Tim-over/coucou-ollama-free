package fr.louisraille.coucou.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF6366F1),
    background = Color(0xFF0E0F13),
    surface = Color(0xFF17181E),
    onBackground = Color(0xFFECEDEF),
    onSurface = Color(0xFFECEDEF),
)

private val Light = lightColorScheme(primary = Color(0xFF6366F1))

@Composable
fun CoucouTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
