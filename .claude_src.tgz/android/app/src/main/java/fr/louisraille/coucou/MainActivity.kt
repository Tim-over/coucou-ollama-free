package fr.louisraille.coucou

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import fr.louisraille.coucou.data.FirebaseLink
import fr.louisraille.coucou.ui.CoucouTheme
import fr.louisraille.coucou.ui.PairScreen
import fr.louisraille.coucou.ui.SessionsScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* best-effort */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // Sign in anonymously, then connect if we already have a pair code.
        lifecycleScope.launch {
            FirebaseLink.signIn()
            if (FirebaseLink.pairId.value != null) {
                FirebaseLink.registerToken()
                FirebaseLink.observe()
            }
        }

        setContent {
            CoucouTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val pairId by FirebaseLink.pairId.collectAsState()
                    if (pairId == null) {
                        PairScreen(onPair = { code ->
                            lifecycleScope.launch { FirebaseLink.pair(this@MainActivity, code) }
                        })
                    } else {
                        SessionsScreen(
                            onDecide = { requestId, decision ->
                                lifecycleScope.launch { FirebaseLink.decide(requestId, decision) }
                            },
                            onUnpair = { FirebaseLink.unpair(this@MainActivity) },
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (FirebaseLink.pairId.value != null) FirebaseLink.observe()
    }
}
