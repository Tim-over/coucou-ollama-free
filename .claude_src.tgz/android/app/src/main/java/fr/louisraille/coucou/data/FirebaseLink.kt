package fr.louisraille.coucou.data

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

/**
 * The single point of contact with Firebase: anonymous sign-in, the pair id, the
 * realtime mirror listener, FCM token registration, and writing decisions.
 *
 * The pair id (shown on the PC in Settings → Phone) scopes everything under
 * pairs/{pairId}. It is the shared secret: anyone with it and a signed-in client
 * can read this pair, so it is long and random.
 */
object FirebaseLink {
    private const val PREFS = "coucou"
    private const val KEY_PAIR = "pairId"

    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    private val _mirror = MutableStateFlow(Mirror())
    val mirror: StateFlow<Mirror> = _mirror

    private val _pairId = MutableStateFlow<String?>(null)
    val pairId: StateFlow<String?> = _pairId

    private val _status = MutableStateFlow("Starting…")
    val status: StateFlow<String> = _status

    private var listener: ListenerRegistration? = null

    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _pairId.value = prefs.getString(KEY_PAIR, null)
    }

    suspend fun signIn(): Boolean = try {
        if (auth.currentUser == null) auth.signInAnonymously().await()
        true
    } catch (e: Exception) {
        _status.value = "Sign-in failed: ${e.message}"
        false
    }

    /** Stores the pair code, (re)starts the listener and registers for push. */
    suspend fun pair(context: Context, code: String) {
        val id = code.trim()
        if (id.isEmpty()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PAIR, id).apply()
        _pairId.value = id
        if (!signIn()) return
        registerToken()
        observe()
    }

    fun unpair(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_PAIR).apply()
        listener?.remove()
        listener = null
        _pairId.value = null
        _mirror.value = Mirror()
    }

    /** Listens to pairs/{pairId}/mirror/state in real time. */
    fun observe() {
        val id = _pairId.value ?: return
        listener?.remove()
        _status.value = "Connecting…"
        listener = db.collection("pairs").document(id)
            .collection("mirror").document("state")
            .addSnapshotListener { snap, err ->
                if (err != null) { _status.value = "Error: ${err.message}"; return@addSnapshotListener }
                if (snap != null && snap.exists()) {
                    _mirror.value = parseMirror(snap)
                    _status.value = "Linked"
                } else {
                    _status.value = "Waiting for the PC…"
                }
            }
    }

    private fun parseMirror(snap: DocumentSnapshot): Mirror {
        @Suppress("UNCHECKED_CAST")
        val raw = snap.get("sessions") as? List<Map<String, Any?>> ?: emptyList()
        val sessions = raw.map { m ->
            Session(
                pillId = m["pillId"] as? String ?: "",
                name = m["name"] as? String ?: "",
                color = m["color"] as? String ?: "#C0C4CC",
                state = m["state"] as? String ?: "idle",
                step = m["step"] as? String ?: "",
                needsApproval = m["needsApproval"] as? Boolean ?: false,
                approvalId = m["approvalId"] as? String ?: "",
                approvalCommand = m["approvalCommand"] as? String ?: "",
            )
        }
        return Mirror(
            pcName = snap.getString("pcName") ?: "",
            sessions = sessions,
            updatedAt = (snap.get("updatedAt") as? Number)?.toLong() ?: 0L,
        )
    }

    /** Registers this device's FCM token so the PC's function can push to it. */
    suspend fun registerToken() {
        val id = _pairId.value ?: return
        try {
            val token = FirebaseMessaging.getInstance().token.await()
            db.collection("pairs").document(id)
                .collection("devices").document(token)
                .set(mapOf("token" to token, "updatedAt" to System.currentTimeMillis())).await()
        } catch (_: Exception) { /* a retry happens on next launch / token refresh */ }
    }

    /** Writes an allow/deny the PC will pick up and apply. */
    suspend fun decide(requestId: String, decision: String): Boolean {
        val id = _pairId.value ?: return false
        return try {
            db.collection("pairs").document(id).collection("decisions").add(
                mapOf(
                    "requestId" to requestId,
                    "decision" to decision,
                    "decidedAt" to System.currentTimeMillis(),
                )
            ).await()
            true
        } catch (e: Exception) {
            _status.value = "Decision failed: ${e.message}"
            false
        }
    }
}
