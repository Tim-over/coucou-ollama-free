package fr.louisraille.coucou.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import fr.louisraille.coucou.data.FirebaseLink
import fr.louisraille.coucou.data.Session
import fr.louisraille.coucou.data.parseColor

@Composable
fun SessionsScreen(onDecide: (String, String) -> Unit, onUnpair: () -> Unit) {
    val mirror by FirebaseLink.mirror.collectAsState()
    val status by FirebaseLink.status.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Coucou", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.weight(1f))
            Text(status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
        if (mirror.pcName.isNotEmpty()) {
            Text(mirror.pcName, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 2.dp))
        }

        if (mirror.sessions.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Mochi("sleeping", Modifier.size(96.dp))
                    Text("Nothing running", modifier = Modifier.padding(top = 12.dp))
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(top = 12.dp),
            ) {
                items(mirror.sessions, key = { it.pillId }) { s ->
                    SessionRow(s, onDecide)
                }
            }
        }

        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onUnpair, modifier = Modifier.fillMaxWidth()) { Text("Unlink this phone") }
    }
}

@Composable
private fun SessionRow(s: Session, onDecide: (String, String) -> Unit) {
    val accent = parseColor(s.color, MaterialTheme.colorScheme.primary)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Mochi(s.state, Modifier.size(40.dp))
                Spacer(Modifier.size(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name.ifEmpty { s.pillId }, style = MaterialTheme.typography.titleMedium, color = accent)
                    Text(
                        if (s.step.isNotEmpty()) s.step else s.state,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    )
                }
            }
            if (s.needsApproval && s.approvalId.isNotEmpty()) {
                if (s.approvalCommand.isNotEmpty()) {
                    Text(
                        s.approvalCommand,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 10.dp),
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 10.dp).fillMaxWidth(),
                ) {
                    OutlinedButton(onClick = { onDecide(s.approvalId, "deny") }, modifier = Modifier.weight(1f)) {
                        Text("Deny")
                    }
                    Button(
                        onClick = { onDecide(s.approvalId, "allow") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                        modifier = Modifier.weight(1f),
                    ) { Text("Allow") }
                }
            }
        }
    }
}
