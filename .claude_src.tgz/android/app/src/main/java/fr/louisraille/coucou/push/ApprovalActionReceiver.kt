package fr.louisraille.coucou.push

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import fr.louisraille.coucou.data.FirebaseLink
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Allow / Deny tapped on the notification: write the decision, clear the banner. */
class ApprovalActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val requestId = intent.getStringExtra(Notifications.EXTRA_REQUEST_ID) ?: return
        val decision = intent.getStringExtra(Notifications.EXTRA_DECISION) ?: return
        FirebaseLink.load(context)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                FirebaseLink.signIn()
                FirebaseLink.decide(requestId, decision)
                Notifications.cancel(context, requestId)
            } finally {
                pending.finish()
            }
        }
    }
}
