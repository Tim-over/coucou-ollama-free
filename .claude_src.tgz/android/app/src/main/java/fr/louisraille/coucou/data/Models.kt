package fr.louisraille.coucou.data

import androidx.compose.ui.graphics.Color

/** One agent session mirrored from the PC (matches phonelink.ts SessionMirror). */
data class Session(
    val pillId: String,
    val name: String,
    val color: String,
    val state: String,
    val step: String,
    val needsApproval: Boolean,
    val approvalId: String,
    val approvalCommand: String,
)

/** The whole mirror document the PC publishes. */
data class Mirror(
    val pcName: String = "",
    val sessions: List<Session> = emptyList(),
    val updatedAt: Long = 0L,
)

/** Colour for a BotState, mirroring the desktop palette closely enough. */
fun stateColor(state: String): Color = when (state) {
    "approval" -> Color(0xFFF5A524)
    "question" -> Color(0xFF8B5CF6)
    "error" -> Color(0xFFF4505E)
    "finished" -> Color(0xFF22C55E)
    "working", "thinking", "searching" -> Color(0xFF6366F1)
    "ratelimit" -> Color(0xFFF59E0B)
    "sleeping" -> Color(0xFF6B7280)
    else -> Color(0xFFC0C4CC)
}

fun parseColor(hex: String, fallback: Color): Color = try {
    val s = hex.removePrefix("#")
    val v = s.toLong(16)
    when (s.length) {
        6 -> Color(0xFF000000 or v)
        8 -> Color(v)
        else -> fallback
    }
} catch (_: Exception) {
    fallback
}
