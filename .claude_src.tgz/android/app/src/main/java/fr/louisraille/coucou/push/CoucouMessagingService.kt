package fr.louisraille.coucou.push

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import fr.louisraille.coucou.data.FirebaseLink
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Receives the FCM data message the Cloud Function sends on a new approval, and
 * raises the Allow/Deny notification — even when the app is not running.
 */
class CoucouMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        when (data["kind"]) {
            "approval" -> {
                val requestId = data["requestId"] ?: return
                Notifications.showApproval(
                    this,
                    requestId,
                    data["title"] ?: "Coucou",
                    data["command"] ?: "",
                )
            }
            "approval-resolved" -> {
                data["requestId"]?.let { Notifications.cancel(this, it) }
            }
        }
    }

    override fun onNewToken(token: String) {
        // Re-register under the current pair, if any.
        FirebaseLink.load(applicationContext)
        CoroutineScope(Dispatchers.IO).launch { FirebaseLink.registerToken() }
    }
}
