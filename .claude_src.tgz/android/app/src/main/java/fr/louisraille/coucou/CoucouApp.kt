package fr.louisraille.coucou

import android.app.Application
import fr.louisraille.coucou.data.FirebaseLink
import fr.louisraille.coucou.push.Notifications

class CoucouApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifications.createChannel(this)
        FirebaseLink.load(this)
    }
}
