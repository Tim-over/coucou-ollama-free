package fr.louisraille.coucou.push

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import fr.louisraille.coucou.R

object Notifications {
    const val CHANNEL = "approvals"
    const val EXTRA_REQUEST_ID = "requestId"
    const val EXTRA_DECISION = "decision"

    fun createChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL, "Approvals", NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "An agent is waiting for your OK" }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    /** A heads-up/lock-screen notification with Allow and Deny actions. */
    fun showApproval(context: Context, requestId: String, title: String, command: String) {
        val allow = action(context, requestId, "allow", "Allow")
        val deny = action(context, requestId, "deny", "Deny")
        val notif = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title.ifEmpty { "Coucou" })
            .setContentText(if (command.isEmpty()) "Waiting for your OK" else command)
            .setStyle(NotificationCompat.BigTextStyle().bigText(command))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .addAction(0, "Deny", deny)
            .addAction(0, "Allow", allow)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(requestId.hashCode(), notif)
        } catch (_: SecurityException) { /* notifications not granted */ }
    }

    fun cancel(context: Context, requestId: String) {
        NotificationManagerCompat.from(context).cancel(requestId.hashCode())
    }

    private fun action(context: Context, requestId: String, decision: String, label: String): PendingIntent {
        val intent = Intent(context, ApprovalActionReceiver::class.java).apply {
            putExtra(EXTRA_REQUEST_ID, requestId)
            putExtra(EXTRA_DECISION, decision)
        }
        return PendingIntent.getBroadcast(
            context,
            (requestId + decision).hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
