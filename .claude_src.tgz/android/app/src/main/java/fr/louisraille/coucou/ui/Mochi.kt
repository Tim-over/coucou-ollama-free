package fr.louisraille.coucou.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import fr.louisraille.coucou.data.stateColor

/**
 * Mochi, drawn in code like the desktop app (a soft rounded square face with two
 * eyes). Not the full animated BotEngine — a still that takes on the state tint.
 */
@Composable
fun Mochi(state: String, modifier: Modifier = Modifier) {
    val tint = stateColor(state)
    Canvas(modifier = modifier) {
        val s = size.minDimension
        val bodyColor = Color.White
        val faceW = s * 0.82f
        val faceH = s * 0.72f
        val left = (size.width - faceW) / 2f
        val top = (size.height - faceH) / 2f

        // A soft coloured glow behind the face.
        drawRoundRect(
            color = tint.copy(alpha = 0.25f),
            topLeft = Offset(left - s * 0.06f, top - s * 0.06f),
            size = Size(faceW + s * 0.12f, faceH + s * 0.12f),
            cornerRadius = CornerRadius(s * 0.34f, s * 0.34f),
        )
        // Face.
        drawRoundRect(
            color = bodyColor,
            topLeft = Offset(left, top),
            size = Size(faceW, faceH),
            cornerRadius = CornerRadius(s * 0.28f, s * 0.28f),
        )
        // Eyes.
        val eyeR = s * 0.055f
        val eyeY = top + faceH * 0.5f
        val eyeDx = faceW * 0.22f
        val cx = left + faceW / 2f
        val eyeColor = Color(0xFF17181E)
        drawCircle(eyeColor, eyeR, Offset(cx - eyeDx, eyeY))
        drawCircle(eyeColor, eyeR, Offset(cx + eyeDx, eyeY))
    }
}
