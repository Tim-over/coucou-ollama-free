# Default Coucou rules. Firebase + Compose ship their own consumer rules.
