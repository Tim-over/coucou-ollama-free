// Coucou push functions.
//
// The PC can't send FCM itself without shipping a server key, so — like the
// iPhone's Cloudflare relay — the secret stays server-side here. The PC just
// writes a doc under pairs/{pairId}/approvals/{id}; this function turns that into
// an FCM data message to every phone registered for the pair. Deleting the doc
// (the request was answered) clears the phone's notification.

const { onDocumentCreated, onDocumentDeleted } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const messaging = admin.messaging();

async function tokensFor(pairId) {
  const snap = await db.collection("pairs").doc(pairId).collection("devices").get();
  return snap.docs.map((d) => d.get("token")).filter(Boolean);
}

async function sendData(pairId, data) {
  const tokens = await tokensFor(pairId);
  if (tokens.length === 0) return;
  // Data-only message: the Android service builds the notification (with Allow /
  // Deny actions) itself, so it works the same in the foreground and background.
  const res = await messaging.sendEachForMulticast({
    tokens,
    data,
    android: { priority: "high" },
  });
  // Drop tokens Firebase reports as gone.
  const stale = [];
  res.responses.forEach((r, i) => {
    if (!r.success) {
      const code = r.error && r.error.code;
      if (code === "messaging/registration-token-not-registered" || code === "messaging/invalid-argument") {
        stale.push(tokens[i]);
      }
    }
  });
  await Promise.all(
    stale.map((t) => db.collection("pairs").doc(pairId).collection("devices").doc(t).delete().catch(() => {})),
  );
}

exports.onApproval = onDocumentCreated("pairs/{pairId}/approvals/{approvalId}", async (event) => {
  const d = event.data && event.data.data();
  if (!d) return;
  await sendData(event.params.pairId, {
    kind: "approval",
    requestId: String(d.requestId || event.params.approvalId),
    title: String(d.title || "Coucou"),
    command: String(d.command || ""),
  });
});

exports.onApprovalResolved = onDocumentDeleted("pairs/{pairId}/approvals/{approvalId}", async (event) => {
  await sendData(event.params.pairId, {
    kind: "approval-resolved",
    requestId: String(event.params.approvalId),
  });
});
