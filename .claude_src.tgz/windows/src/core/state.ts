// App state — mirror of AppState.swift (the parts the island needs).

import type { BotEmoteName, BotStateName, IslandMode, IslandViewName } from "./layout";
import type { EyeShape } from "../mochi/engine";

export type AgentSource = "claudeCode" | "n8n";
export type PillBadge = "approval" | "finished" | "error";

export interface AgentTask {
  id: string;
  name: string;
  color: string;
  state: BotStateName;
  stepIndex: number;
  steps: string[];
  source: AgentSource;
  isIntegration: boolean;
  emote?: BotEmoteName | null;
  miniEye?: EyeShape | null;
  pillBadge?: PillBadge | null;
  sessionCwd?: string | null;
}

export interface ApprovalInfo {
  requestId: string;
  sessionId: string;
  tool: string;
  command: string;
}

export interface ChatMessage {
  id: number;
  role: "user" | "assistant";
  content: string;
  /** A file Coucou wrote (a corrected .docx): the reply offers Open / Show. */
  output?: string;
  /** Short label shown in the user bubble instead of a long generated query. */
  label?: string;
  /** Ollama timing for this answer: tokens/s and token counts. */
  stats?: { tokensPerSec: number; evalCount: number; promptCount: number; totalMs: number };
}

export interface DroppedRef {
  name: string;
  /** Copy in the inbox, what the models read. */
  path: string;
  /** Where it was dragged from — where a corrected copy is written. */
  source: string;
}

export const FR = typeof navigator !== "undefined" && navigator.language.toLowerCase().startsWith("fr");

export type PromptContext =
  | { kind: "window"; appName: string; title: string; url?: string }
  | { kind: "file"; name: string; path?: string };

export interface ResultItem {
  label: string;
  detail: string;
  url?: string;
}

export interface SearchResult {
  title: string;
  items: ResultItem[];
  note?: string;
}

const task = (
  id: string, name: string, color: string, source: AgentSource,
): AgentTask => ({
  id, name, color, state: "idle", stepIndex: 0, steps: [], source, isIntegration: true,
});

/** AgentTask.integrationAgents — same ids, names and colours as macOS. */
export const INTEGRATION_AGENTS: AgentTask[] = [
  task("integration_claude", "VS Code", "#F5F6F8", "claudeCode"),
  task("integration_resend", "Resend", "#22C55E", "n8n"),
  task("integration_n8n", "n8n", "#F29B38", "n8n"),
  task("integration_vercel", "Vercel", "#7C5CFF", "n8n"),
  task("integration_github", "GitHub", "#F4505E", "n8n"),
  task("integration_notion", "Notion", "#8C8C8C", "n8n"),
  task("integration_calcom", "Cal.com", "#C9956A", "n8n"),
  task("integration_stripe", "Stripe", "#0570DE", "n8n"),
];

export const TOGGLEABLE_INTEGRATION_IDS = [
  "integration_resend", "integration_n8n", "integration_vercel", "integration_github",
  "integration_notion", "integration_calcom", "integration_stripe",
];

/** What an integration poller last reported. */
export interface IntegrationInfo {
  data: Record<string, unknown>;
  error: string | null;
  loaded: boolean;
  configured: boolean;
}

export interface Settings {
  soundEnabled: boolean;
  soundVolume: number;
  autoCloseInterval: number;
  absenceInterval: number;
  activeIntegrations: string[];
  screen: "primary" | "cursor";
  autostart: boolean;
  hooksInstalled: boolean;
  /** Claude model used by the chat. */
  model: string;
  /** Mochi accessory id (see Outfit in engine). */
  outfit: string;
  /** Which engine answers: the Anthropic API or a local Ollama model. */
  provider: "claude" | "ollama";
  ollamaUrl: string;
  ollamaModel: string;
  /** Context window asked of Ollama (num_ctx). */
  ollamaCtx: number;
  /** Global shortcut that corrects the selection in any app, or "off". */
  quickfixShortcut: string;
  /** React when you copy text/a URL anywhere (Mochi peeks and offers to help). */
  clipboardReaction: boolean;
  /** Mochi changes mood with activity (dozes when idle, cheers on success…). */
  moodReactions: boolean;
  /** Running total of Ollama output tokens generated ("how much I use"). */
  ollamaTokensUsed: number;
  /** Mirror sessions & approvals to the Android companion via Firebase. */
  phoneLinkEnabled: boolean;
  /** Random id shared with the paired phone (the pair's bearer secret). */
  phoneLinkPairId: string;
  /** Firebase Web API key (publishable per Firebase design). */
  firebaseApiKey: string;
  /** Firebase project id. */
  firebaseProjectId: string;
}

export const DEFAULT_SETTINGS: Settings = {
  soundEnabled: true,
  soundVolume: 0.12,
  autoCloseInterval: 15,
  absenceInterval: 180,
  activeIntegrations: [
    "integration_resend", "integration_n8n", "integration_vercel", "integration_github",
  ],
  screen: "primary",
  autostart: false,
  hooksInstalled: false,
  model: "claude-opus-5-5",
  outfit: "none",
  provider: "claude",
  ollamaUrl: "http://localhost:11434",
  ollamaModel: "",
  ollamaCtx: 8192,
  quickfixShortcut: "Ctrl+Alt+Shift+C",
  clipboardReaction: true,
  moodReactions: true,
  ollamaTokensUsed: 0,
  phoneLinkEnabled: false,
  phoneLinkPairId: "",
  firebaseApiKey: "",
  firebaseProjectId: "",
};

/** Name shown in the UI for whoever answers the chat. */
export function engineLabel(s: Settings): string {
  if (s.provider === "ollama") {
    return s.ollamaModel ? s.ollamaModel.replace(/:latest$/, "") : "Ollama";
  }
  return "Claude";
}

type Listener = () => void;

class AppState {
  mode: IslandMode = "hidden";
  view: IslandViewName = "overview";

  tasks: AgentTask[] = [];
  focusId: string | null = null;

  stateOverride: BotStateName | null = null;

  /** Cursor in logical screen pixels, origin top-left (like AppState.mousePosition). */
  mouse = { x: 0, y: 0 };
  /** Cursor relative to the island's top-left corner. */
  mouseInIsland = { x: 0, y: 0 };

  isPinned = false;
  paused = false;

  uploadProgress = 0;
  /** True while Mochi is being thrown (the ghost follows the cursor instead). */
  throwing = false;
  uploadDuration = 2.4;
  fileDragOver = false;

  promptContext: PromptContext | null = null;
  /** Everything in the last drop (a folder drop is expanded to its files). */
  droppedFiles: DroppedRef[] = [];
  /** A window Mochi was thrown onto (non-browser): its app name + title. */
  windowContext: { appName: string; title: string; url: string | null } | null = null;
  /** Raw text to act on (copied, or dragged onto Mochi) — correct/translate/summarize. */
  textContext: string | null = null;
  /** Optional action buttons shown under a note (clipboard/text offers). */
  noteActions: { label: string; primary?: boolean; run: () => void }[] | null = null;
  /** Short label for the next queued user bubble (hides a long generated query). */
  pendingLabel: string | null = null;
  noteMessage: string | null = null;
  searchResult: SearchResult | null = null;
  chatHistory: ChatMessage[] = [];
  /** A quick action (Correct, Summarize…) queued for the chat to send on open. */
  pendingQuery: string | null = null;
  /** Text to drop into the chat input without sending (editable default). */
  prefill: string | null = null;
  /** Which quick action queued it — "correct" on a .docx writes a corrected copy. */
  pendingAction: "correct" | "summarize" | null = null;
  pendingApproval: ApprovalInfo | null = null;

  integrations: Record<string, IntegrationInfo> = {};

  lastActivity = performance.now();

  settings: Settings = { ...DEFAULT_SETTINGS };

  /** First dropped file — the one the upload animation names. */
  get droppedFile(): DroppedRef | null {
    return this.droppedFiles[0] ?? null;
  }

  /** "rapport.pdf", or "3 fichiers" / "3 files" for a multi-drop. */
  get droppedLabel(): string {
    const n = this.droppedFiles.length;
    if (n === 0) return "file";
    if (n === 1) return this.droppedFiles[0].name;
    return FR ? `${n} fichiers` : `${n} files`;
  }

  private listeners = new Set<Listener>();

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** Marks the UI dirty; the island re-renders on the next frame. */
  notify() {
    for (const fn of this.listeners) fn();
  }

  private moodTimer = 0;
  /** Briefly show a mood on Mochi (happy on success, etc.), then clear it. */
  flashMood(state: BotStateName, ms = 1500) {
    if (!this.settings.moodReactions) return;
    this.stateOverride = state;
    this.notify();
    window.clearTimeout(this.moodTimer);
    this.moodTimer = window.setTimeout(() => {
      if (this.stateOverride === state) {
        this.stateOverride = null;
        this.notify();
      }
    }, ms) as unknown as number;
  }

  get focusTask(): AgentTask | null {
    return this.tasks.find((t) => t.id === this.focusId) ?? this.tasks[0] ?? null;
  }

  get effectiveState(): BotStateName {
    return this.stateOverride ?? this.focusTask?.state ?? "idle";
  }

  get otherTasks(): AgentTask[] {
    return this.tasks.filter((t) => t.id !== this.focusId);
  }

  setFocus(id: string) {
    const t = this.tasks.find((x) => x.id === id);
    if (!t) return;
    this.focusId = id;
    t.pillBadge = null;
    this.notify();
  }

  updateTask(id: string, state: BotStateName) {
    const t = this.tasks.find((x) => x.id === id);
    if (!t) return;
    t.state = state;
    this.notify();
  }

  appendStep(id: string, step: string) {
    const t = this.tasks.find((x) => x.id === id);
    if (!t) return;
    t.steps.push(step);
    if (t.steps.length > 20) t.steps.shift();
    t.stepIndex = t.steps.length - 1;
    this.notify();
  }

  setPillBadge(id: string, badge: PillBadge | null) {
    const t = this.tasks.find((x) => x.id === id);
    if (!t) return;
    t.pillBadge = badge;
    this.notify();
  }

  /** loadIntegrationTasks() — VS Code always on, the rest opt-in (max 4). */
  loadIntegrationTasks() {
    for (const proto of INTEGRATION_AGENTS) {
      const shouldLoad =
        proto.id === "integration_claude" || this.settings.activeIntegrations.includes(proto.id);
      const idx = this.tasks.findIndex((t) => t.id === proto.id);
      if (shouldLoad && idx < 0) this.tasks.push({ ...proto, steps: [] });
      if (!shouldLoad && idx >= 0) this.tasks.splice(idx, 1);
    }
    // Keep the declared order so pills never shuffle.
    const order = INTEGRATION_AGENTS.map((t) => t.id);
    this.tasks.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
    if (!this.focusId) this.focusId = "integration_claude";
    this.notify();
  }

  toggleIntegration(id: string) {
    if (id === "integration_claude") return;
    const active = this.settings.activeIntegrations;
    if (active.includes(id)) {
      this.settings.activeIntegrations = active.filter((x) => x !== id);
      if (this.focusId === id) this.focusId = "integration_claude";
    } else {
      if (active.length >= 4) return;
      this.settings.activeIntegrations = [...active, id];
    }
    this.loadIntegrationTasks();
  }

  defaultView(): IslandViewName {
    return this.tasks.length === 0 ? "empty" : "overview";
  }
}

export const State = new AppState();
