// Preferences, stored as plain JSON in %APPDATA%\Coucou\settings.json.
// No secret ever lands here — API keys live in the Windows Credential Manager.

use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Settings {
    pub sound_enabled: bool,
    pub sound_volume: f64,
    pub auto_close_interval: f64,
    pub absence_interval: f64,
    pub active_integrations: Vec<String>,
    /// "primary" = the main display, "cursor" = whichever display the mouse is on.
    pub screen: String,
    pub autostart: bool,
    pub hooks_installed: bool,
    /// Claude model used by the chat. Changeable in the settings window.
    /// Defaulted explicitly so a settings.json written by an older build still loads.
    #[serde(default = "default_model")]
    pub model: String,
    /// Which engine answers in the chat: "claude" (Anthropic API) or "ollama"
    /// (a model running locally). Older settings.json files default to Claude.
    #[serde(default = "default_provider")]
    pub provider: String,
    /// Where Ollama listens. Plain preference, not a secret.
    #[serde(default = "default_ollama_url")]
    pub ollama_url: String,
    /// Local model name as Ollama lists it, e.g. "gemma3:4b".
    #[serde(default)]
    pub ollama_model: String,
    /// Context window asked of Ollama (num_ctx). Bigger reads longer PDFs but
    /// needs more memory.
    #[serde(default = "default_ollama_ctx")]
    pub ollama_ctx: u32,
    /// Global shortcut that corrects the selected text in any app, or "off".
    #[serde(default = "default_quickfix_shortcut")]
    pub quickfix_shortcut: String,
}

/// Ctrl+Alt+Shift: AltGr alone is Ctrl+Alt on AZERTY keyboards, so a plain
/// Ctrl+Alt chord would swallow characters like €.
pub const DEFAULT_QUICKFIX_SHORTCUT: &str = "Ctrl+Alt+Shift+C";

fn default_quickfix_shortcut() -> String {
    DEFAULT_QUICKFIX_SHORTCUT.into()
}

fn default_model() -> String {
    crate::claude::DEFAULT_MODEL.to_string()
}

fn default_provider() -> String {
    "claude".into()
}

fn default_ollama_url() -> String {
    crate::ollama::DEFAULT_URL.to_string()
}

fn default_ollama_ctx() -> u32 {
    crate::ollama::DEFAULT_CTX
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            sound_enabled: true,
            sound_volume: 0.12,
            auto_close_interval: 15.0,
            absence_interval: 180.0,
            active_integrations: vec![
                "integration_resend".into(),
                "integration_n8n".into(),
                "integration_vercel".into(),
                "integration_github".into(),
            ],
            screen: "primary".into(),
            autostart: false,
            hooks_installed: false,
            model: default_model(),
            provider: default_provider(),
            ollama_url: default_ollama_url(),
            ollama_model: String::new(),
            ollama_ctx: default_ollama_ctx(),
            quickfix_shortcut: default_quickfix_shortcut(),
        }
    }
}

/// %APPDATA%\Coucou
pub fn config_dir() -> PathBuf {
    let base = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("."));
    base.join("Coucou")
}

/// %LOCALAPPDATA%\Coucou — where coucou-hook.exe and the log live.
pub fn local_dir() -> PathBuf {
    let base = std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("."));
    base.join("Coucou")
}

pub fn hook_exe_path() -> PathBuf {
    local_dir().join("bin").join("coucou-hook.exe")
}

fn settings_path() -> PathBuf {
    config_dir().join("settings.json")
}

pub fn load() -> Settings {
    match std::fs::read(settings_path()) {
        Ok(bytes) => serde_json::from_slice(&bytes).unwrap_or_default(),
        Err(_) => Settings::default(),
    }
}

pub fn save(settings: &Settings) -> std::io::Result<()> {
    let dir = config_dir();
    std::fs::create_dir_all(&dir)?;
    let json = serde_json::to_vec_pretty(settings)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
    std::fs::write(settings_path(), json)
}
