// Quick actions offered after a file drop. They are ordinary chat questions,
// queued in State.pendingQuery and sent as soon as the chat opens, so the
// answer lands in the same dialog as any other reply and can be followed up.

import { State } from "./state";

export type QuickAction = "correct" | "summarize";

import { FR } from "./state";

const PROMPTS: Record<QuickAction, { fr: string; en: string }> = {
  correct: {
    fr: "Corrige toutes les fautes de ce fichier (orthographe, grammaire, conjugaison, ponctuation, tournures maladroites) sans changer le sens ni le ton. Donne d'abord le texte corrigé en entier, puis la liste des corrections avec une courte explication pour chacune.",
    en: "Proofread this file: fix every spelling, grammar, punctuation and awkward-phrasing mistake without changing the meaning or tone. First give the full corrected text, then list each correction with a short explanation.",
  },
  summarize: {
    fr: "Résume ce fichier : l'essentiel en 3 à 5 phrases, puis les points clés, les chiffres ou dates importants et ce qu'il faut en retenir ou faire.",
    en: "Summarize this file: the gist in 3 to 5 sentences, then the key points, important figures or dates, and what to remember or do next.",
  },
};

export const QUICK_LABELS: Record<QuickAction, string> = FR
  ? { correct: "Corriger", summarize: "Résumer" }
  : { correct: "Correct it", summarize: "Summarize" };

/** Queues the action; the chat view sends it when it opens. */
export function queueQuick(action: QuickAction) {
  State.pendingQuery = FR ? PROMPTS[action].fr : PROMPTS[action].en;
  State.pendingAction = action;
}

/** Short label shown in the user's bubble instead of the long prompt. */
export function quickBubble(query: string): string | null {
  for (const key of Object.keys(PROMPTS) as QuickAction[]) {
    if (PROMPTS[key].fr === query || PROMPTS[key].en === query) return `✦ ${QUICK_LABELS[key]}`;
  }
  return null;
}
